chrome.management.onDisabled.addListener(function(info){

    if(info.name=="ToolsZen"){
      
        chrome.cookies.getAll({domain: "buzzsumo.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://app.buzzsumo.com" + cookies[i].path, name: cookies[i].name});
            }
        });
       
          chrome.cookies.getAll({domain: "spyfu.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://www.spyfu.com" + cookies[i].path, name: cookies[i].name});
            }
        });

       chrome.cookies.getAll({domain: "skillshare.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://www.skillshare.com" + cookies[i].path, name: cookies[i].name});
            }
        });

        
        chrome.cookies.getAll({domain: "canva.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://www.canva.com/" + cookies[i].path, name: cookies[i].name});
            }
        });  

		chrome.cookies.getAll({domain: "quetext.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://www.quetext.com" + cookies[i].path, name: cookies[i].name});
            }
        });

       	chrome.cookies.getAll({domain: "serpstat.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://serpstat.com/" + cookies[i].path, name: cookies[i].name});
            }
        });

         chrome.cookies.getAll({domain: "lynda.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://www.lynda.com" + cookies[i].path, name: cookies[i].name});
            }
        });

           chrome.cookies.getAll({domain: "moz.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://moz.com" + cookies[i].path, name: cookies[i].name});
            }
        });

        chrome.cookies.getAll({domain: "semrush.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://www.semrush.com" + cookies[i].path, name: cookies[i].name});
            }
        });

        chrome.cookies.getAll({domain: "ahrefs.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://ahrefs.com" + cookies[i].path, name: cookies[i].name});
            }
        });
       
        
       chrome.cookies.getAll({domain: "keywordtool.io"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://keywordtool.io" + cookies[i].path, name: cookies[i].name});
            }
        });


        chrome.cookies.remove({
                url: 'https://app.grammarly.com',
                name: "grauth"
            });


         chrome.cookies.getAll({domain: "wordai.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://wordai.com" + cookies[i].path, name: cookies[i].name});
            }
        });

         chrome.cookies.getAll({domain: "semscoop.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://semscoop.com" + cookies[i].path, name: cookies[i].name});
            }
        });

        chrome.cookies.getAll({domain: "crello.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://crello.com" + cookies[i].path, name: cookies[i].name});
            }
        });
       

         chrome.cookies.getAll({domain: "keywordrevealer.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://www.keywordrevealer.com" + cookies[i].path, name: cookies[i].name});
            }
        });

        chrome.cookies.getAll({domain: "piktochart.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://create.piktochart.com" + cookies[i].path, name: cookies[i].name});
            }
        });

        chrome.cookies.getAll({domain: "picmonkey.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://www.picmonkey.com" + cookies[i].path, name: cookies[i].name});
            }
        });
        
       chrome.cookies.getAll({domain: "animoto.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://animoto.com" + cookies[i].path, name: cookies[i].name});
            }
        });

        chrome.cookies.getAll({domain: "alexa.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "http://www.alexa.com" + cookies[i].path, name: cookies[i].name});
            }
        });
        
         chrome.cookies.getAll({domain: "woorank.com"}, function(cookies) {
            for(var i=0; i<cookies.length;i++) {
                chrome.cookies.remove({url: "https://www.woorank.com" + cookies[i].path, name: cookies[i].name});
            }
        });
        
       
        chrome.tabs.query({}, function (tabs) {
            for (var i = 0; i < tabs.length; i++) {
                    chrome.tabs.reload(tabs[i].id);
            }
        });
        
    }
    
});

var id = chrome.runtime.id;
chrome.runtime.onMessageExternal.addListener(function(msg, sender, sendResponse) {
    if ((msg.action == "id") && (msg.value == id))
    {
        sendResponse({id : id});
    }
});