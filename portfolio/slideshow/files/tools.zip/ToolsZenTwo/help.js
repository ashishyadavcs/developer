chrome.webRequest.onBeforeRequest.addListener(function(details)
{
  return {cancel:true};
},
{urls:
[ "*://*.ahrefs.com/account/*","*://*.ahrefs.com/user/logout*","*://*.semrush.com/sso/*","*://*.semrush.com/billing-admin/*","*://*.semrush.com/billing/*","*://*.semrush.com/prices/*","*://*.moz.com/logout/*","*://*.moz.com/community/*","*://*.moz.com/account/*","*://*.members.frozenfry.com/*","*://*.frozenfry.com/members/*","*://*.moz.com/subscriptions/*","*://*.moz.com/auth/*","*://*.moz.com/billing/*","*://*.moz.com/checkout/*","*://*.moz.com/email/*","*://*.moz.com/users/auth/*","*://*.alexa.com/account/*","*://*.alexa.com/logout*","*://*.semrush.com/accounts/*","*://*.alexa.com/pro/subscription*","*://*.alexa.com/password/change*","*://*.alexa.com/email/requestchange*","*://*.magisto.com/account*","*://*.seoprofiler.com/account/*","*://*.spyfu.com/account/*","*://*.spyfu.com/auth/logout*","*://*.spinrewriter.com/action/log-out*","*://*.elements.envato.com/sign-out*","*://*.keywordrevealer.com/auth/logout*","*://*.keywordrevealer.com/auth/profile*","*://*.app.buzzsumo.com/settings/*","*://*.woorank.com/en/logout*","*://*.woorank.com/en/user/*","*://*.canva.com/account*","*://*.canva.com/logout*","*://*.linkedin.com/psettings/*","*://*.linkedin.com/m/logout/*","*://*.linkedin.com/help/learning*","*://*.linkedin.com/learning/logout*","*://*.skillshare.com/help*","*://*.skillshare.com/profile/*","*://*.skillshare.com/settings/*","*://*.skillshare.com/teams*","*://*.skillshare.com/help*","*://*.skillshare.com/logout*","*://*.stockunlimited.com/account*","*://*.stockunlimited.com/purchase_plan.php*","*://*.stockunlimited.com/download_history.php*","*://*.stockunlimited.com/preferences.php*","*://*.stockunlimited.com/auth_action.php?action=logout*","*://*.freepik.com/profile/preagreement/getstarted*","*://*.freepik.com/profile/my_subscriptions*","*://*.support.freepik.com/*","*://*.pngtree.com/login/logout*","*://*.pngtree.com/user/my-subscriptions*","*://*.upload.pngtree.com/?r=upload*","*://*.pngtree.com/invite-friends*","*://*.pngtree.com/user/my-profile*","*://*.pngtree.com/notice*","*://*.support.storyblocks.com/*","*://*.storyblocks.com/member/logout*","*://*.videoblocks.com/member/profile*","*://*.support.audioblocks.com/*","*://*.audioblocks.com/member/logout*","*://*.indexification.com/support.php*","*://*.indexification.com/members/integration.php*","*://*.indexification.com/members/api.php*","*://*.indexification.com/members/billing.php*","*://*.indexification.com/members/profile.php*","*://*.articlebuilder.net/?action=logout*","*://*.copywritely.com/account/*","*://*.app.ninjaoutreach.com/Settings*","*://*.app.ninjaoutreach.com/StripeWorkflow*","*://*.renderforest.com/logout*","*://*.renderforest.com/subscription*","*://*.renderforest.com/profile*","*://*.netflix.com/YourAccount*","*://*.netflix.com/SignOut*",]},
["blocking"]
);

function clearcookies() {
    chrome.cookies.getAll({
        domain: "semrush.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.semrush.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "skillshare.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.skillshare.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "keywordtool.io"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://keywordtool.io" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "semscoop.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://semscoop.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "quetext.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.quetext.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "picmonkey.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.picmonkey.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "serpstat.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://serpstat.com/" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "moz.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://moz.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "woorank.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.woorank.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "animoto.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://animoto.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "lynda.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.lynda.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "canva.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.canva.com/" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "netflix.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://netflix.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.remove({
        url: "https://app.grammarly.com",
        name: "grauth"
    }), chrome.tabs.query({}, function(e) {
        for (var o = 0; o < e.length; o++) chrome.tabs.reload(e[o].id)
    })

}
chrome.browserAction.onClicked.addListener(function(e) {
    chrome.cookies.getAll({
        domain: "semrush.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.semrush.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "skillshare.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.skillshare.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "keywordtool.io"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://keywordtool.io" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "semscoop.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://semscoop.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "quetext.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.quetext.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "picmonkey.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.picmonkey.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "serpstat.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://serpstat.com/" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "moz.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://moz.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "woorank.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.woorank.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "animoto.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://animoto.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "lynda.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.lynda.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "canva.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://www.canva.com/" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.getAll({
        domain: "netflix.com"
    }, function(e) {
        for (var o = 0; o < e.length; o++) chrome.cookies.remove({
            url: "https://netflix.com" + e[o].path,
            name: e[o].name
        })
    }), chrome.cookies.remove({
        url: "https://app.grammarly.com",
        name: "grauth"
    }), chrome.tabs.query({}, function(e) {
        for (var o = 0; o < e.length; o++) chrome.tabs.reload(e[o].id)
    })
});
var CE = "hlkenndednhfkekhgcdicdfddnkalmdm";
chrome.management.get(CE, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Cookie-Editor Detect Please Remove then use our services"), chrome.management.uninstall(CE), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "hlkenndednhfkekhgcdicdfddnkalmdm" == e.id && (clearcookies(), alert("Cookie-Editor installing Detect Please Remove then use our services"), chrome.management.uninstall(CE), chrome.management.uninstallSelf())
});
var ETC = "fngmhnnpilhplaeedifhccceomclgfbg";
chrome.management.get(ETC, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("EditThisCookie Detect Please Remove then use our services"), chrome.management.uninstall(ETC), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "fngmhnnpilhplaeedifhccceomclgfbg" == e.id && (clearcookies(), alert("EditThisCookie installing Detect Please Remove then use our services"), chrome.management.uninstall(ETC), chrome.management.uninstallSelf())
});
var CAD = "fhcgjolkccmbidfldomjliifgaodjagh";
chrome.management.get(CAD, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Cookie AutoDelete Detect Please Remove then use our services"), chrome.management.uninstall(CAD), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "fhcgjolkccmbidfldomjliifgaodjagh" == e.id && (clearcookies(), alert("Cookie AutoDelete installing Detect Please Remove then use our services"), chrome.management.uninstall(CAD), chrome.management.uninstallSelf())
});
var SU = "fanfmpddlmekneofaoeijddmadflebof";
chrome.management.get(SU, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("ShareUrl Detect Please Remove then use our services"), chrome.management.uninstall(SU), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "fanfmpddlmekneofaoeijddmadflebof" == e.id && (clearcookies(), alert("ShareUrl installing Detect Please Remove then use our services"), chrome.management.uninstall(SU), chrome.management.uninstallSelf())
});
var SA = "glifngepkcmfolnojchcfiinmjgeablm";
chrome.management.get(SA, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("ShareAccount Detect Please Remove then use our services"), chrome.management.uninstall(SA), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "glifngepkcmfolnojchcfiinmjgeablm" == e.id && (clearcookies(), alert("ShareAccount installing Detect Please Remove then use our services"), chrome.management.uninstall(SA), chrome.management.uninstallSelf())
});
var SS = "dldfccnkgldjoochmlhcbhljmlbcgdao";
chrome.management.get(SS, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("ShareSessions Detect Please Remove then use our services"), chrome.management.uninstall(SS), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "dldfccnkgldjoochmlhcbhljmlbcgdao" == e.id && (clearcookies(), alert("Share Sessions installing Detect Please Remove then use our services"), chrome.management.uninstall(SS), chrome.management.uninstallSelf())
});
var CI = "jgbbilmfbammlbbhmmgaagdkbkepnijn";
chrome.management.get(CI, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("CookieInspector Detect Please Remove then use our services"), chrome.management.uninstall(CI), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "jgbbilmfbammlbbhmmgaagdkbkepnijn" == e.id && (clearcookies(), alert("CookieInspector installing Detect Please Remove then use our services"), chrome.management.uninstall(CI), chrome.management.uninstallSelf())
});
var CM = "bjdaiadcbbcomhnlhpnbmnnfcnhkiibj";
chrome.management.get(CM, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("CookieManager Detect Please Remove then use our services"), chrome.management.uninstall(CM), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "bjdaiadcbbcomhnlhpnbmnnfcnhkiibj" == e.id && (clearcookies(), alert("Cookie Manager installing Detect Please Remove then use our services"), chrome.management.uninstall(CM), chrome.management.uninstallSelf())
});
var DS = "lknhpplgahpbindnnocglcjonpahfikn";
chrome.management.get(DS, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("DeveloperCookie Detect Please Remove then use our services"), chrome.management.uninstall(DS), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "lknhpplgahpbindnnocglcjonpahfikn" == e.id && (clearcookies(), alert("Developer Cookie installing Detect Please Remove then use our services"), chrome.management.uninstall(DS), chrome.management.uninstallSelf())
});
var EC1 = "eognaopbbjmpompmibmllnddafjhbfdj";
chrome.management.get(EC1, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("EditCookie Detect Please Remove then use our services"), chrome.management.uninstall(EC1), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "eognaopbbjmpompmibmllnddafjhbfdj" == e.id && (clearcookies(), alert("EditCookie installing Detect Please Remove then use our services"), chrome.management.uninstall(EC1), chrome.management.uninstallSelf())
});
var SWC = "dffhipnliikkblkhpjapbecpmoilcama";
chrome.management.get(SWC, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("SwapMyCookies Detect Please Remove then use our services"), chrome.management.uninstall(SWC), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "dffhipnliikkblkhpjapbecpmoilcama" == e.id && (clearcookies(), alert("Swap My Cookies installing Detect Please Remove then use our services"), chrome.management.uninstall(SWC), chrome.management.uninstallSelf())
});
var GCFF = "embffhododclmgpnabmjmgoekpnoboic";
chrome.management.get(GCFF, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("GetCookieForFPlus Detect Please Remove then use our services"), chrome.management.uninstall(GCFF), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "embffhododclmgpnabmjmgoekpnoboic" == e.id && (clearcookies(), alert("Get Cookie For FPlus installing Detect Please Remove then use our services"), chrome.management.uninstall(GCFF), chrome.management.uninstallSelf())
});
var SSER = "cahmhpmgmcgbhafeickhklifhoonfala";
chrome.management.get(SSER, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("SessionSwitcher Detect Please Remove then use our services"), chrome.management.uninstall(SSER), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "cahmhpmgmcgbhafeickhklifhoonfala" == e.id && (clearcookies(), alert("Session Switcher installing Detect Please Remove then use our services"), chrome.management.uninstall(SSER), chrome.management.uninstallSelf())
});
var CSTA = "maejjihldgmkjlfmgpgoebepjchengka";
chrome.management.get(CSTA, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("ClearSession Detect Please Remove then use our services"), chrome.management.uninstall(CSTA), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "maejjihldgmkjlfmgpgoebepjchengka" == e.id && (clearcookies(), alert("Clear Session installing Detect Please Remove then use our services"), chrome.management.uninstall(CSTA), chrome.management.uninstallSelf())
});
var YZ = "iiidlaodookaobikpdnlpacodackhbfk";
chrome.management.get(YZ, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Youzign Detect Please Remove then use our services"), chrome.management.uninstall(YZ), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "iiidlaodookaobikpdnlpacodackhbfk" == e.id && (clearcookies(), alert("Youzign installing Detect Please Remove then use our services"), chrome.management.uninstall(YZ), chrome.management.uninstallSelf())
});
var EASFGF = "mnannclpojfocmcjfhoicjbkjllajfhg";
chrome.management.get(EASFGF, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("EasyAccountSwitcherforGoogleFacebook. Detect Please Remove then use our services"), chrome.management.uninstall(EASFGF), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "mnannclpojfocmcjfhoicjbkjllajfhg" == e.id && (clearcookies(), alert("Easy Account Switcher for Google, Facebook. installing Detect Please Remove then use our services"), chrome.management.uninstall(EASFGF), chrome.management.uninstallSelf())
});
var SBML = "megbklhjamjbcafknkgmokldgolkdfig";
chrome.management.get(SBML, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("SessionBox - Free multi login to any website. Detect Please Remove then use our services"), chrome.management.uninstall(SBML), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "megbklhjamjbcafknkgmokldgolkdfig" == e.id && (clearcookies(), alert("SessionBox - Free multi login to any website. installing Detect Please Remove then use our services"), chrome.management.uninstall(SBML), chrome.management.uninstallSelf())
});
var MSB = "hojmmbfmaddjdkkcgbiipkphdcfmkhge";
chrome.management.get(MSB, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("MultiSessionBox - Multi login any website Detect Please Remove then use our services"), chrome.management.uninstall(MSB), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "hojmmbfmaddjdkkcgbiipkphdcfmkhge" == e.id && (clearcookies(), alert("Multi Session Box - Multi login any website Detect Please Remove then use our services"), chrome.management.uninstall(MSB), chrome.management.uninstallSelf())
});
var ACM = "hcpidejphgpcgfnpiehkcckkkemgneif";
chrome.management.get(ACM, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("AwesomeCookieManager Detect Please Remove then use our services"), chrome.management.uninstall(ACM), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "hcpidejphgpcgfnpiehkcckkkemgneif" == e.id && (clearcookies(), alert("Awesome Cookie Manager installing Detect Please Remove then use our services"), chrome.management.uninstall(ACM), chrome.management.uninstallSelf())
});
var CMCD = "idmefaajmbkeajdiafefcleiaihkahnm";
chrome.management.get(CMCD, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Checkmycookies Detect Please Remove then use our services"), chrome.management.uninstall(CMCD), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "idmefaajmbkeajdiafefcleiaihkahnm" == e.id && (clearcookies(), alert("Check my cookies installing Detect Please Remove then use our services"), chrome.management.uninstall(CMCD), chrome.management.uninstallSelf())
});
var JSF = "bcjindcccaagfpapjjmafapmmgkkhgoa";
chrome.management.get(JSF, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("JSONFormatter Detect Please Remove then use our services"), chrome.management.uninstall(JSF), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "bcjindcccaagfpapjjmafapmmgkkhgoa" == e.id && (clearcookies(), alert("JSON Formatter installing Detect Please Remove then use our services"), chrome.management.uninstall(JSF), chrome.management.uninstallSelf())
});
var VCMD = "gieohaicffldbmiilohhggbidhephnjj";
chrome.management.get(VCMD, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("VanillaCookieManager Detect Please Remove then use our services"), chrome.management.uninstall(VCMD), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "gieohaicffldbmiilohhggbidhephnjj" == e.id && (clearcookies(), alert("Vanilla Cookie Manager installing Detect Please Remove then use our services"), chrome.management.uninstall(VCMD), chrome.management.uninstallSelf())
});
var RDTD = "lmhkpmbekcpmknklioeibfkpmmfibljd";
chrome.management.get(RDTD, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("ReduxDevTools Detect Please Remove then use our services"), chrome.management.uninstall(RDTD), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "lmhkpmbekcpmknklioeibfkpmmfibljd" == e.id && (clearcookies(), alert("Redux DevTools installing Detect Please Remove then use our services"), chrome.management.uninstall(RDTD), chrome.management.uninstallSelf())
});
var RCFS = "lmhkpmbekcpmknklioeibfkpmmfibljd";
chrome.management.get(RCFS, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("RemoveCookiesForSite Detect Please Remove then use our services"), chrome.management.uninstall(RCFS), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "lmhkpmbekcpmknklioeibfkpmmfibljd" == e.id && (clearcookies(), alert("RemoveCookiesForSite installing Detect Please Remove then use our services"), chrome.management.uninstall(RCFS), chrome.management.uninstallSelf())
});
var J2TEAM = "okpidcojinmlaakglciglbpcpajaibco";
chrome.management.get(J2TEAM, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("J2TEAMCookies Detect Please Remove then use our services"), chrome.management.uninstall(J2TEAM), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "okpidcojinmlaakglciglbpcpajaibco" == e.id && (clearcookies(), alert("J2TEAM Cookies installing Detect Please Remove then use our services"), chrome.management.uninstall(J2TEAM), chrome.management.uninstallSelf())
});
var RCD2 = "oifomnalkciipmgkfgdjkepdocgiipjg";
chrome.management.get(RCD2, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("RemoveCookie Detect Please Remove then use our services"), chrome.management.uninstall(RCD2), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "oifomnalkciipmgkfgdjkepdocgiipjg" == e.id && (clearcookies(), alert("Remove Cookie installing Detect Please Remove then use our services"), chrome.management.uninstall(RCD2), chrome.management.uninstallSelf())
});
var cookiz = "gigjlpmaigooaojjkekgpjkmmlhegjne";
chrome.management.get(cookiz, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("cookiz Detect Please Remove then use our services"), chrome.management.uninstall(cookiz), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "gigjlpmaigooaojjkekgpjkmmlhegjne" == e.id && (clearcookies(), alert("cookiz installing Detect Please Remove then use our services"), chrome.management.uninstall(cookiz), chrome.management.uninstallSelf())
});
var CC2D = "cbmeppphogddecgcngpdiknecdacbkoa";
chrome.management.get(CC2D, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("CookieCleaner Detect Please Remove then use our services"), chrome.management.uninstall(CC2D), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "cbmeppphogddecgcngpdiknecdacbkoa" == e.id && (clearcookies(), alert("Cookie Cleaner installing Detect Please Remove then use our services"), chrome.management.uninstall(CC2D), chrome.management.uninstallSelf())
});
var Tamper = "hifhgpdkfodlpnlmlnmhchnkepplebkb";
chrome.management.get(Tamper, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Tamper Chrome Detect Please Remove then use our services"), chrome.management.uninstall(Tamper), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "hifhgpdkfodlpnlmlnmhchnkepplebkb" == e.id && (clearcookies(), alert("Tamper Chrome installing Detect Please Remove then use our services"), chrome.management.uninstall(Tamper), chrome.management.uninstallSelf())
});
var RMDN = "kajfghlhfkcocafkcjlajldicbikpgnp";
chrome.management.get(RMDN, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("RequestMaker Detect Please Remove then use our services"), chrome.management.uninstall(RMDN), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "kajfghlhfkcocafkcjlajldicbikpgnp" == e.id && (clearcookies(), alert("Request Maker installing Detect Please Remove then use our services"), chrome.management.uninstall(RMDN), chrome.management.uninstallSelf())
});
var ChocoChip = "cdllihdpcibkhhkidaicoeeiammjkokm";
chrome.management.get(ChocoChip, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("ChocoChip - Cookie Manager Detect Please Remove then use our services"), chrome.management.uninstall(ChocoChip), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "cdllihdpcibkhhkidaicoeeiammjkokm" == e.id && (clearcookies(), alert("ChocoChip - Cookie Managerinstalling Detect Please Remove then use our services"), chrome.management.uninstall(ChocoChip), chrome.management.uninstallSelf())
});
var ModHeader = "idgpnmonknjnojddfkpgkljpfnnfcklj";
chrome.management.get(ModHeader, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("ModHeader Detect Please Remove then use our services"), chrome.management.uninstall(ModHeader), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "idgpnmonknjnojddfkpgkljpfnnfcklj" == e.id && (clearcookies(), alert("ModHeaderinstalling Detect Please Remove then use our services"), chrome.management.uninstall(ModHeader), chrome.management.uninstallSelf())
});
var BlockClick = "bofdamlbkfkjnecfjbhpncokfalmmbii";
chrome.management.get(BlockClick, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Enable Right Click Detect Please Remove then use our services"), chrome.management.uninstall(BlockClick), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "bofdamlbkfkjnecfjbhpncokfalmmbii" == e.id && (clearcookies(), alert("Enable Right Click installing Detect Please Remove then use our services"), chrome.management.uninstall(BlockClick), chrome.management.uninstallSelf())
});
var RightClick = "hhojmcideegachlhfgfdhailpfhgknjm";
chrome.management.get(RightClick, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Enable Right Click Detect Please Remove then use our services"), chrome.management.uninstall(RightClick), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "hhojmcideegachlhfgfdhailpfhgknjm" == e.id && (clearcookies(), alert("Enable Right Click installing Detect Please Remove then use our services"), chrome.management.uninstall(RightClick), chrome.management.uninstallSelf())
});
var FClick = "jdocbkpgdakpekjlhemmfcncgdjeiika";
chrome.management.get(RightClick, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Enable Right Click Detect Please Remove then use our services"), chrome.management.uninstall(FClick), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "jdocbkpgdakpekjlhemmfcncgdjeiika" == e.id && (clearcookies(), alert("Enable Right Click installing Detect Please Remove then use our services"), chrome.management.uninstall(FClick), chrome.management.uninstallSelf())
});
var SessionDisable = "lhobbakbeomfcgjallalccfhfcgleinm";
chrome.management.get(SessionDisable, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Session Alive Detect Please Remove then use our services"), chrome.management.uninstall(SessionDisable), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "lhobbakbeomfcgjallalccfhfcgleinm" == e.id && (clearcookies(), alert("Session Alive installing Detect Please Remove then use our services"), chrome.management.uninstall(SessionDisable), chrome.management.uninstallSelf())
});
var Toolspackage = "gpjkpemlagalekonfpcmllmhmlfghbka";
chrome.management.get(Toolspackage, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Toolspackage Extension Detect Please Remove then use our services"), chrome.management.uninstall(Toolspackage), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "gpjkpemlagalekonfpcmllmhmlfghbka" == e.id && (clearcookies(), alert("Toolspackage Extension installing Detect Please Remove then use our services"), chrome.management.uninstall(Toolspackage), chrome.management.uninstallSelf())
});
var Seoopentools = "mjbbklfhiacjaifmedmnaghbjglcacie";
chrome.management.get(Seoopentools, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Seoopentools Extension Detect Please Remove then use our services"), chrome.management.uninstall(Seoopentools), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "mjbbklfhiacjaifmedmnaghbjglcacie" == e.id && (clearcookies(), alert("Seoopentools Extension installing Detect Please Remove then use our services"), chrome.management.uninstall(Seoopentools), chrome.management.uninstallSelf())
});
var Fry = "dnacggjlcbpfcfchkkogedlkenpnlfbi";
chrome.management.get(Fry, function(e) {
    chrome.runtime.lastError || (clearcookies(), alert("Frozenfry Extension Detect Please Remove then use our services"), chrome.management.uninstall(Fry), chrome.management.uninstallSelf())
}), chrome.management.onEnabled.addListener(function(e) {
    "dnacggjlcbpfcfchkkogedlkenpnlfbi" == e.id && (clearcookies(), alert("Frozenfry Extension installing Detect Please Remove then use our services"), chrome.management.uninstall(Fry), chrome.management.uninstallSelf())
});